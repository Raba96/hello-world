var LocalStrategy   = require('passport-local').Strategy;

var mysql = require('mysql');
var bcrypt = require('bcrypt-nodejs');
var dbconfig = require('./database');
var connection = mysql.createConnection(dbconfig.connection);

connection.query('USE ' + dbconfig.database);

module.exports = function(passport) {

    passport.serializeUser(function(user, done) {
        done(null, user.id);
    });


    passport.deserializeUser(function(id, done) {
        connection.query("SELECT * FROM users WHERE id = ? ",[id], function(err, rows){
            done(err, rows[0]);
        });
    });


    passport.use(
        'local-signup',
        new LocalStrategy({
            usernameField : 'username',
            passwordField : 'password',          
            passReqToCallback : true 
        },
		
        function(req, username, password, done) {	
			var password2 = req.body.password2;
			var email = req.body.email;
			if(password != password2){
				
					
				    return done(null, false, req.flash('signupMessage', "Confirm Password Doesn't match.")); 
				
			}
			
			else{
				 connection.query("SELECT * FROM users WHERE username = '"+username+"' or email= '"+email+"'", function(err, rows) {
					var email = req.body.email;	
						if (err)
							return done(err);
						if (rows.length) {
							console.log(email);
							var newemail = rows[0].email;
							// if(!newemail == email){				
								// console.log(email);
								// return done(null, false, req.flash('signupMessage', "That emqil is already taken.")); 
								
							// }
								return done(null, false, req.flash('signupMessage', 'That username/email is already taken. Please use different email and username.'));
						
							
						}else {
											

							var newUserMysql = {
								username: username,
								password: bcrypt.hashSync(password, null, null),
								email: email,
								
							};

							var insertQuery = "INSERT INTO users ( username, password, email) values (?,?,?)";
							
							// console.log(email);
							// console.log(newUserMysql);
							connection.query(insertQuery,[newUserMysql.username, newUserMysql.password, newUserMysql.email],function(err, rows) {
							   newUserMysql.id = rows.insertId;
								console.log(newUserMysql);
								return done(null, newUserMysql);
								
							});
							
							return done(null, false, req.flash('signupMessage', "You Are Registered Successfully")); 
						}
					}); 
			  
			  
			}
			
       })
    );

    passport.use(
        'local-login',
        new LocalStrategy({
            
            usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true 
        },
        function(req, username, password, done) { 
            connection.query("SELECT * FROM users WHERE username = ?",[username], function(err, rows){
                if (err)
                    return done(err);
                if (!rows.length) {
                    return done(null, false, req.flash('loginMessage', 'Not Found.')); 
                }

           
                if (!bcrypt.compareSync(password, rows[0].password))
                    return done(null, false, req.flash('loginMessage', 'Wrong password.'));

          
                return done(null, rows[0]);
            });
        })
    );
};
